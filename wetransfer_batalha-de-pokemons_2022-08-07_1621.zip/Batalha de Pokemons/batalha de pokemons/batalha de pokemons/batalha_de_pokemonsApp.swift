

import SwiftUI

@main
struct batalha_de_pokemonsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
