//
//  PokemonBatalhaApp.swift
//  PokemonBatalha
//
//  Created by Diogopedro on 28/07/2022.
//

import SwiftUI

@main
struct PokemonBatalhaApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
