//
//  batalha.swift
//  PokemonBatalha
//
//  Created by Diogopedro on 30/07/2022.
//

import SwiftUI

struct batalha: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct batalha_Previews: PreviewProvider {
    static var previews: some View {
        batalha()
    }
}
